package com.zeta.service;

import java.util.List;
import java.util.Optional;

import com.zeta.model.Loan;

public interface Myservice {
	public List<Loan> getLoans();
	public Loan getLoanByNo(int loanNo);
	public Loan addNewLoan(Loan loan);
	public Loan updateLoan(Loan loan);
	public void deleteLoanByNo(int loanNo);
	public void deleteAllLoans();
	
}
