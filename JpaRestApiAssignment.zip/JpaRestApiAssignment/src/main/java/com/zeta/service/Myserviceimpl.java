package com.zeta.service;

import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zeta.dao.Mydaorepository;
import com.zeta.model.Loan;

import junit.framework.Assert;

@Service
public class Myserviceimpl implements Myservice{
	
	@Autowired
	Mydaorepository dao;
	public List<Loan> getLoans() {
		return dao.findAll();
	}
	
	public Loan getLoanByNo(int loanNo) {
		// TODO Auto-generated method stub
		
		return dao.findOne(loanNo); 
	}

	public Loan addNewLoan(Loan loan) {
		// TODO Auto-generated method stub
		return dao.save(loan);
	}

	public Loan updateLoan(Loan loan) {
		// TODO Auto-generated method stub
		return dao.save(loan);
	}
	
	public void deleteLoanByNo(int loanNo) {
		 dao.delete(loanNo);
		
	}

	public void deleteAllLoans() {
		dao.deleteAll();
		
	}

}
