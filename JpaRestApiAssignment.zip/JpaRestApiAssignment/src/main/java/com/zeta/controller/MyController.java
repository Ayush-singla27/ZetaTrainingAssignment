package com.zeta.controller;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zeta.consumer.ApiConsumer;
import com.zeta.model.Loan;
import com.zeta.service.Myservice;

import junit.framework.Assert;

@RestController
public class MyController {
	@Autowired
	Myservice service;
	ApiConsumer apiCons = new ApiConsumer();
	 
	@RequestMapping("/loan/all")
	@Test 
	public List<Loan> getLoan(){
		Log4jTest.helper(MyController.class).info(this.getClass().getSimpleName() + " - Get all employee is invoked.");
		List<Loan> temp = service.getLoans();
		return temp;
	}
	
	@RequestMapping(value= "/loan/{no}", method= RequestMethod.GET)
	public Loan getLoanByNo(@PathVariable int no) throws Exception {
		Log4jTest.helper(MyController.class).info(this.getClass().getSimpleName() + " - Get employee details by id is invoked.");
		Loan loan = service.getLoanByNo(no);

		return loan;
	}
 
	@RequestMapping(value= "/loan/add", method= RequestMethod.POST)
	public Loan createLoan(@RequestBody Loan newLoan) {
		Log4jTest.helper(MyController.class).info(this.getClass().getSimpleName() + " - Create new employee method is invoked.");
		return service.addNewLoan(newLoan);
	}

	@RequestMapping(value= "/loan/update/{no}", method= RequestMethod.PUT)
	public Loan updateLoan(@RequestBody Loan loanNo, @PathVariable int no) throws Exception {
		Log4jTest.helper(MyController.class).info(this.getClass().getSimpleName() + " - Update employee details by id is invoked.");

		Loan loan =  service.getLoanByNo(no);
		loanNo.setLoanNo(no);
		return service.updateLoan(loanNo);
	}

	@RequestMapping(value= "/loan/delete/{no}", method= RequestMethod.DELETE)
	public void deleteLoanByNo(@PathVariable int no) throws Exception {
		Log4jTest.helper(MyController.class).info(this.getClass().getSimpleName() + " - Delete employee by id is invoked.");

		Loan loan =  service.getLoanByNo(no);

		service.deleteLoanByNo(no);
	}

	@RequestMapping(value= "/loan/deleteall", method= RequestMethod.DELETE)
	public void deleteAll() {
		Log4jTest.helper(MyController.class).info(this.getClass().getSimpleName() + " - Delete all employees is invoked.");
		service.deleteAllLoans();
	}
	
	@RequestMapping(value= "/loan/consumer", method= RequestMethod.GET)
	public Object consumerApi() {
		return apiCons.consumer();
	}
}
