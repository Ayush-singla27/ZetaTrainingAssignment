	package com.zeta.jUnitService;

import java.awt.PageAttributes.MediaType;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;

import org.junit.Test;
import org.springframework.core.*;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import junit.framework.Assert;

public class ApiTesting {

	@Test
	public void consumerTest() throws IOException,HttpClientErrorException{
//		String url = "https://reqres.in/api/users";
//		RestTemplate template = new RestTemplate();
//		ResponseEntity<String> obj = template.getForEntity(url, String.class);
//		
//		System.out.println(obj.getBody());
		try {
            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            //headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            headers.add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
            HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

            ResponseEntity response = restTemplate.exchange("http://localhost:9998/loan/all", HttpMethod.GET,entity,Object.class);
            Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);
            Assert.assertNotNull(response.getBody());
            
            ResponseEntity response1 = restTemplate.exchange("http://localhost:9998/loan/2", HttpMethod.GET,entity,Object.class);
            Assert.assertEquals(response1.getStatusCode(), HttpStatus.OK);
            Assert.assertNotNull(response1.getBody());
            
//            ResponseEntity response2 = restTemplate.exchange("http://localhost:9998/delete/6", HttpMethod.GET,entity,Object.class);
//            Assert.assertEquals(response2.getStatusCode(), HttpStatus.OK);
            

        } catch (Exception ex) {
           ex.printStackTrace();
        }
		
		
	}

}
