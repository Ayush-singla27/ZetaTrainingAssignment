package com.zeta.jUnitService;


import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.zeta.dao.Mydaorepository;
import com.zeta.model.Loan;
import com.zeta.service.Myserviceimpl;

public class MyserviceimplUnitTest {
	
	@InjectMocks
	Myserviceimpl service = new Myserviceimpl();
	
	@Mock
	Mydaorepository dao;
	
	@Before
	public void fun() {
		 MockitoAnnotations.initMocks(this);
	}
	@Test
	public void addtest() {
		Mockito.when(dao.findAll()).thenReturn(new ArrayList<Loan>());
		service.getLoans();
		Mockito.verify(dao, Mockito.times(1)).findAll();
	}
}
